<?php 
return array (
  'BASIC_THEME' => 'newpi',
  'DEFAULT_THEME' => 'san',
);