<?php

define('FTX_VERSION', '6.0');
define('FTX_RELEASE', '2016-06-23 02');
?>