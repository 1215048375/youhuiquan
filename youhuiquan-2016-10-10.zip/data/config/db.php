<?php
return array (
  'DB_HOST' => 'localhost',
  'DB_NAME' => 'yhq',
  'DB_USER' => 'root',
  'DB_PWD' => 'xiaojiezou99Z!',
  'DB_PORT' => '3306',
  'DB_PREFIX' => 'yhq_',
);