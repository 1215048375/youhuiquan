<?php if (!defined('THINK_PATH')) exit();?><html>
<head>
</head>
<body>
<div id="jump"></div>
<script>
var jump = document.createElement('iframe');
jump.src = 'javascript:top.location.replace("<?php echo ($item["click_url"]); ?>")';
jump.width=0;
jump.height=0;
document.getElementById('jump').appendChild(jump);
</script>
</body>
</html>