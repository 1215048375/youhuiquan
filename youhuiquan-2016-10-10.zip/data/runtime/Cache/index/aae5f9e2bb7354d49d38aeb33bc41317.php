<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
<title><?php echo ($page_seo["title"]); ?></title>
<meta name="keywords" content="<?php echo ($page_seo["keywords"]); ?>" />
<meta name="description" content="<?php echo ($page_seo["description"]); ?>" />
<meta name="generator" content="yangtata" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="language" content="zh-CN">
<meta http-equiv="X-UA-Compatible" content="IE=edge,Chrome=1">
<meta name="renderer" content="webkit">
<link rel="stylesheet" type="text/css" href="__STATIC__/san_www/css/reset.css">
<link rel="stylesheet" type="text/css" href="__STATIC__/san_www/css/footer.css">
<link rel="stylesheet" type="text/css" href="__STATIC__/san_www/css/pager.css">
<link rel="stylesheet" type="text/css" href="__STATIC__/san_www/css/allsan.css">
<link rel="stylesheet" type="text/css" href="__STATIC__/san_www/css/iconfont.css">
<link rel="stylesheet" type="text/css" href="__STATIC__/san_www/css/index.css">
<link rel="stylesheet" type="text/css" href="__STATIC__/san_www/css/detail.css" />
<link rel="shortcut icon" type="image/ico" href="/favicon.ico">
<link rel="bookmark" href="/favicon.ico"/>
<script src="__STATIC__/san_www/js/jquery.js"></script>
<script src="__STATIC__/san_www/js/layer/layer.js"></script>
<script src="__STATIC__/san_www/js/unslider.min.js"></script>
<?php if(C('ftx_site_zidong') == '1'): ?><script type="text/javascript">
function is_mobile() {
    var regex_match = /(nokia|iphone|android|motorola|^mot-|softbank|foma|docomo|kddi|up.browser|up.link|htc|dopod|blazer|netfront|helio|hosin|huawei|novarra|CoolPad|webos|techfaith|palmsource|blackberry|alcatel|amoi|ktouch|nexian|samsung|^sam-|s[cg]h|^lge|ericsson|philips|sagem|wellcom|bunjalloo|maui|symbian|smartphone|midp|wap|phone|windows ce|iemobile|^spice|^bird|^zte-|longcos|pantech|gionee|^sie-|portalmmm|jigs browser|hiptop|^benq|haier|^lct|operas*mobi|opera*mini|320x320|240x320|176x220)/i;
    var u = navigator.userAgent;
    if (null == u) {
        return true;
    }
    var result = regex_match.exec(u);
    if (null == result) {
        return false
    } else {
        return true
    }
}
if (is_mobile()) {
    document.location.href = "<?php echo C('ftx_header_html'); echo ($item["url"]); ?>";
	}
	</script><?php endif; ?>
</head>
<body>
<style>
    #navTop {
        width: 100%;

        /*border-bottom: 1px solid #ccc;*/
    }

    .toTop {
        font-family: iconfont;
        position: fixed;
        right: 70px;
        bottom: 70px;
        line-height: 50px;
        text-align: center;
        border: 1px solid #CCCCCC;
        border-radius: 50px;
        color: #858585;
        width: 50px;
        font-size: 36px;
        cursor: pointer;
        background-color: #fff;
    }

    .toTop:hover, .toTop:focus {
        color: rgb(234, 42, 96);
    }

    body #headNav #header #showList dl {
        margin: 5px 16px;
    }

    body #headNav #header #showList #search button {
        height: 37px;
        overflow: hidden;
        padding: 7px 30px;
    }
</style>
<div id="navTop">
<div id="top">
<ul id="topleft" style="height:30px;line-height:25px;">
<li style=" margin-right:20px;float:left"><a href="javascript:void(0)" onclick="SetHome(this,window.location)" style="color: #757575;" title="加入收藏，方便下次打开">设为首页</a></li>
<li style=" margin-right:20px;float:left"><a href="javascript:void(0)" onclick="shoucang(document.title,window.location)" style="color: #757575;" title="加入收藏，方便下次打开">加入收藏</a></li>
<li style="float:left"><a href="<?php echo C('ftx_header_html');?>" target="_blank"><em class="icon-normal icon-phone"></em>手机版</a></li>
</ul>
<ul id="topright" style="line-height: 25px;">
<li><a target="_blank" style="color: #8da7cb" href="http://wpa.qq.com/msgrd?v=3&amp;uin=<?php echo C('ftx_qq');?>&amp;site=qq&amp;menu=yes">在线客服</a></li>
</ul>
<div class="clear"></div>
</div>
</div>
<div id="headNav">
<div id="header" style="padding-bottom: 10px;">
<a href="/" style="width: 400px; height: 55px;display: inline-block;float: left;    background-size: inherit;    background: url('<?php echo C('ftx_site_logo');?>')left top no-repeat;margin-top: 15px;">
</a>
<div id="showList">
<div id="search">
<form name="search" action="<?php echo C('ftx_site_url');?>" method="get">
<input type="hidden" name="m" value="search">
<input type="hidden" name="a" value="index">
<input type="text" x-webkit-speech name="k" autocomplete="off" onblur="this.value==''?this.value=this.title:null" onfocus="this.value==this.title?this.value='':null" title="搜优惠券..." value="搜优惠券..." />
<button type="submit">搜索</button>
</form> 
</div>
<dl>
<dt class="rg"></dt>
</dl>
<dl>
<dt class="zy"></dt>
</dl>
<dl>
<dt class="qc"></dt>
</dl>
</div>
<div class="clear"></div>
</div>
</div>
<div id="baner">
<div id="nav" style="font-size: 15px;">
<?php $tag_nav_class = new navTag;$data = $tag_nav_class->lists(array('type'=>'lists','style'=>'main','status'=>'1','cache'=>'0','return'=>'data',)); if(is_array($data)): $i = 0; $__LIST__ = $data;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$val): $mod = ($i % 2 );++$i;?><a class="<?php if($nav_curr == $val['alias']): if($val['alias'] == hot): ?>iconH<?php endif; if($val['alias'] == index): ?>iconM<?php endif; ?> active<?php endif; ?>" href="<?php echo ($val["link"]); ?>" <?php if($val['alias'] == index): ?>style="padding:8px 27px;"<?php else: ?>style="padding:8px 15px;"<?php endif; ?> <?php if($val["target"] == 1): ?>target="_blank"<?php endif; ?>><?php if($val['alias'] == index): ?><i class="iconfont">&#xe601;</i><span style="margin-right: 7px;"><?php echo ($val["name"]); ?></span><?php else: echo ($val["name"]); endif; if($val['alias'] == hot): ?><div style="position:absolute; width:24px; height:32px; background:#FFCC00;margin-left: 107px; margin-top: -25px; background:url(__STATIC__/san_www/images/HOTT_qeu.gif)"></div><?php endif; ?></a><?php endforeach; endif; else: echo "" ;endif; ?>
</div>
</div>
<div id="dtk_mian">
<div class="search-wrap main-container">
</div>
<div class="detail-wrap main-container">
<div class="nav-wrap">
<div class="text">当前位置：<a href="<?php echo C('ftx_site_url');?>">首页</a>&gt;<a href="<?php echo U('index/cate', array('cid'=>$item['cate_id']));?>"><?php echo ($item['cname']); ?></a>&gt;&nbsp;优惠详情
</div>
</div>
<div class="detail-row clearfix">
<a rel="nofollow" <?php echo ($item["ckurl"]); ?> target="_blank" class="img"><img src="<?php echo attach(get_thumb($item['pic_url'], '_f'),'item');?>" alt=""></a>
<div class="detail-col">
<a class="title clearfix" rel="nofollow" <?php echo ($item["ckurl"]); ?> target="_blank">
<?php if($item["shop_type"] == 'B' ): ?><span class="tmall"></span>
<?php else: ?>
<span class="taobao"></span><?php endif; ?>
<span class="title" style="font-weight: bold;"><?php echo ($item["title"]); ?></span>
</a>
<div class="desc" style="height: 40px; margin-top:8px;color: #FF6788;"> <span style="color: #FF6788;font-weight: bold;">推荐理由：</span><?php echo ($item["intro"]); ?> </div>
<?php if($item["item_type"] == '2' ): ?><div class="coupon-wrap clearfix" style="margin-top: 18px;height: 70px;background-color: #FFDDDD;">
<div class="text" style="margin-top:25px;">券后价&nbsp;&nbsp;￥</div>
<div class="price" style="font-family:Arial;font-size: 36px; margin-left:3px; margin-top:10px; color:#E63739;"><?php echo ($item["coupon_price"]); ?></div>
<div class="org-price" style="color: #EF839A;margin-top: 25px;">
正常售价&nbsp;&nbsp;￥<?php echo ($item["price"]); ?></div>
<div class="right" style="color: #B9B8B9; top:18px;border-left: 1px solid #E2C8C8;">
已有<span class="sold-num" style="color: #949494;padding: 0 5px;font-family:Arial;"><?php echo ($item["volume"]); ?></span>人购买
</div>
</div>
<div class="coupon-text-wrap">
独享优惠券<span class="price"><?php echo ($item["q_price"]); ?></span>元<span class="text2">*&nbsp;已领<span class="sold-num"><?php echo ($item["q_has"]); ?></span>张，手慢无</span>
</div>
<div class="flow-wrap" style="height: 168px;">
<div class="text1">购买流程：</div>
<a class="coupon" <?php echo ($item["ckurl"]); ?> target="_blank">点击先领券&nbsp;&gt;</a>
<img class="arrow" src="__STATIC__/san_www/images/arrow-right.png" alt="">
<a class="goto" <?php echo ($item["ckurl"]); ?> rel="nofollow" target="_blank" style="color: #FFFFFF;">去<?php echo ($type); ?>下单&nbsp;&gt;</a>
<?php else: ?>
<div class="coupon-wrap clearfix" style="margin-top: 18px;height: 70px;background-color: #FFDDDD;">
<div class="text" style="margin-top:25px;">折扣价&nbsp;&nbsp;￥</div>
<div class="price" style="font-family:Arial;font-size: 36px; margin-left:3px; margin-top:10px; color:#E63739;"><?php echo ($item["coupon_price"]); ?></div>
<div class="org-price" style="color: #EF839A;margin-top: 25px;">
原价&nbsp;&nbsp;￥<?php echo ($item["price"]); ?></div>
<div class="right" style="color: #B9B8B9; top:18px;border-left: 1px solid #E2C8C8;">
已有<span class="sold-num" style="color: #949494;padding: 0 5px;font-family:Arial;"><?php echo ($item["volume"]); ?></span>人购买
</div>
</div>
<div class="flow-wrap" style="height: 168px;">
<a class="goto" <?php echo ($item["ckurl"]); ?> rel="nofollow" target="_blank" style="color: #FFFFFF;left:200px;padding: 15px 40px;font-size:18px">去<?php echo ($type); ?>购买&nbsp;&gt;</a><?php endif; ?>
<div class="text2" style="top: 130px;">如果你喜欢此宝贝，记得分享给您的朋友，一起享优惠：</div>
<div class="bdshare" style=" top: 125px;">
<div class="bdsharebuttonbox">
<a href="#" class="bds_more" data-cmd="more"></a>
<a href="#" class="bds_qzone" data-cmd="qzone" title="分享到QQ空间"></a>
<a href="#" class="bds_tsina" data-cmd="tsina" title="分享到新浪微博"></a>
<a href="#" class="bds_weixin" data-cmd="weixin" title="分享到微信"></a>
</div>
<script>
window._bd_share_config = {
"common": {
"bdSnsKey": {},
"bdText": "<?php echo ($item["intro"]); ?>",
"bdMini": "2",
"bdMiniList": false,
"bdPic": "<?php echo ($item["pic_url"]); ?>",
"bdStyle": "0",
"bdSize": "16"
}, "share": {}
};
with (document)0[(getElementsByTagName('head')[0] || body).appendChild(createElement('script')).src = 'http://bdimg.share.baidu.com/static/api/js/share.js?v=89860593.js?cdnversion=' + ~(-new Date() / 36e5)];</script>
</div>
</div>
</div>
</div>
</div>
<div class="jipin-wrap">
<img src="__STATIC__/san_www/images/jinpintuijian.png" alt="">
</div>
<div class="goods-list main-container">
<ul class="clearfix index-boutique">
<?php if(is_array($items_list)): $i = 0; $__LIST__ = $items_list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 4 );++$i;?><li class="<?php if(($mod) == "3"): ?>no-right<?php endif; ?>">
<a <?php echo ($item["itemurl"]); ?> class="img" rel="nofollow" target="_blank">
<?php echo (sannewicon($item["coupon_start_time"])); ?>
<img src="<?php echo attach(get_thumb($item['pic_url'], '_b'),'item');?>" alt="">
</a>
<div class="padding">
<a target="_blank" <?php echo ($item["itemurl"]); ?> class="title clearfix">
<?php if($item["shop_type"] == 'B' ): ?><i class="tmall"></i>
<?php else: ?>
<i class="taobao"></i><?php endif; ?>
<span><?php echo ($item["title"]); ?></span>
</a>
<?php if($item["item_type"] == '2' ): ?><div class="coupon-wrap clearfix">
优惠券<span class="price"><?php echo ($item["q_price"]); ?></span>元，已有<span class="num"><?php echo ($item["volume"]); ?></span>人购买
</div>
<?php else: ?>
<div class="price-wrap clearfix" style="background:none;">
<span class="icon">￥</span>
<span class="price"><?php echo ($item["coupon_price"]); ?></span>
<span class="youpin"></span>
<div class="sold-count">
<span class="num"><?php echo ($item["zk"]); ?> 折</span>
</div>
</div>
<div class="time-wrap clearfix">
<div class="date">
目前已售<?php echo ($item["volume"]); ?>
</div>
<a class="buy" <?php echo ($item["ckurl"]); ?> target="_blank" rel="nofollow">去抢购&gt;</a>
</div><?php endif; ?>
</div>
<?php if($item["item_type"] == '2' ): ?><div class="price-wrap clearfix">
<span class="price">
<span class="text">券后价&nbsp;￥<span class="price"><?php echo ($item["coupon_price"]); ?></span></span>
<span class="text" style="margin-left: 15px; font-size: 12px;color: #ffe4ed;">正常售价&nbsp;￥<?php echo ($item["price"]); ?> </span>
</span>
</div><?php endif; ?>
</li><?php endforeach; endif; else: echo "" ;endif; ?>
</ul>
</div>
</div>
<div id="footer" style="background-color: #373737;height: 190px;width: 100%;border-top: 3px solid #ff3366;">
<div class="footer-wrapper " style="width: 1200px;margin: 0 auto;position: relative;text-align: center">
<img src="__STATIC__/san_www/images/bottom_text.png" alt="" style="border: 0;margin-top: 50px;">

<div class="text" style="color: #a2a2a2;
    font-size: 16px;
    margin-top: 33px;">Copyright &copy; 2010 - 2016  <a href="<?php echo C('ftx_site_url');?>"><?php echo C('ftx_site_name');?></a> All Rights Reserved  <?php echo C('ftx_statistics_code');?> &nbsp;<a href="http://www.miibeian.gov.cn" target="_blank"><?php echo C('ftx_site_icp');?></a> &nbsp;&nbsp; 
</div>
</div>
</div>
<div class="toTop" style="display: none" onclick=" $('body,html').animate({scrollTop:0},1000);">
&#xe60c;</div>
<script type="text/javascript">
    // 设置为主页
    function SetHome(obj, vrl) {
        try {
            obj.style.behavior = 'url(#default#homepage)';
            obj.setHomePage(vrl);
        }
        catch (e) {
            if (window.netscape) {
                try {
                    netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");
                }
                catch (e) {
                    alert("此操作被浏览器拒绝！\n请在浏览器地址栏输入“about:config”并回车\n然后将 [signed.applets.codebase_principal_support]的值设置为'true',双击即可。");
                }
                var prefs = Components.classes['@mozilla.org/preferences-service;1'].getService(Components.interfaces.nsIPrefBranch);
                prefs.setCharPref('browser.startup.homepage', vrl);
            } else {
                alert("您的浏览器不支持，请按照下面步骤操作：1.打开浏览器设置。2.点击设置网页。3.输入：" + vrl + "点击确定。");
            }
        }
    }
    // 加入收藏 兼容360和IE6
    function shoucang(sTitle, sURL) {
        try {
            window.external.addFavorite(sURL, sTitle);
        }
        catch (e) {
            try {
                window.sidebar.addPanel(sTitle, sURL, "");
            }
            catch (e) {
                alert("加入收藏失败，请使用Ctrl+D进行添加");
            }
        }
    }

    $(function () {

        $(window).scroll(function () {
            if ($(window).scrollTop() > 500) {
                $(".toTop").fadeIn(1000);
            }
            else {
                $(".toTop").fadeOut(1000);
            }
        });
    });
</script>
<script type="text/javascript">
var yangtataER = {
    root: "__ROOT__",
	site: "<?php echo C('ftx_site_url');?>"
};
var lang = {};
<?php $_result=L('js_lang');if(is_array($_result)): $i = 0; $__LIST__ = $_result;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$val): $mod = ($i % 2 );++$i;?>lang.<?php echo ($key); ?> = "<?php echo ($val); ?>";<?php endforeach; endif; else: echo "" ;endif; ?>
</script>
<script type="text/javascript" src="__STATIC__/san_www/js/scrollTop2.js"></script>
<?php echo C('ftx_taojindian_html');?>
</body>
</html>