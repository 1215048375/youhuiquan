<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
<title><?php echo ($page_seo["title"]); ?></title>
<meta name="keywords" content="<?php echo ($page_seo["keywords"]); ?>" />
<meta name="description" content="<?php echo ($page_seo["description"]); ?>" />
<meta name="generator" content="yangtata" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="language" content="zh-CN">
<meta http-equiv="X-UA-Compatible" content="IE=edge,Chrome=1">
<meta name="renderer" content="webkit">
<link rel="stylesheet" type="text/css" href="__STATIC__/san_www/css/reset.css">
<link rel="stylesheet" type="text/css" href="__STATIC__/san_www/css/footer.css">
<link rel="stylesheet" type="text/css" href="__STATIC__/san_www/css/pager.css">
<link rel="stylesheet" type="text/css" href="__STATIC__/san_www/css/allsan.css">
<link rel="stylesheet" type="text/css" href="__STATIC__/san_www/css/iconfont.css">
<link rel="stylesheet" type="text/css" href="__STATIC__/san_www/css/index.css">
<link rel="shortcut icon" type="image/ico" href="/favicon.ico">
<link rel="bookmark" href="/favicon.ico"/>
<script src="__STATIC__/san_www/js/jquery.js"></script>
<script src="__STATIC__/san_www/js/layer.js"></script>
<script src="__STATIC__/san_www/js/unslider.min.js"></script>
<?php if(C('ftx_site_zidong') == '1'): ?><script type="text/javascript">
function is_mobile() {
    var regex_match = /(nokia|iphone|android|motorola|^mot-|softbank|foma|docomo|kddi|up.browser|up.link|htc|dopod|blazer|netfront|helio|hosin|huawei|novarra|CoolPad|webos|techfaith|palmsource|blackberry|alcatel|amoi|ktouch|nexian|samsung|^sam-|s[cg]h|^lge|ericsson|philips|sagem|wellcom|bunjalloo|maui|symbian|smartphone|midp|wap|phone|windows ce|iemobile|^spice|^bird|^zte-|longcos|pantech|gionee|^sie-|portalmmm|jigs browser|hiptop|^benq|haier|^lct|operas*mobi|opera*mini|320x320|240x320|176x220)/i;
    var u = navigator.userAgent;
    if (null == u) {
        return true;
    }
    var result = regex_match.exec(u);
    if (null == result) {
        return false
    } else {
        return true
    }
}
if (is_mobile()) {
    document.location.href = "<?php echo C('ftx_header_html');?>";
	}
	</script><?php endif; ?>


<style>
    #dtk_mian {
        background: url("__STATIC__/san_www/images/bg.png") top center repeat-y;
    }

    
    body #content .discount .dis_product .pro_detail {
        border: 1px solid #e0e0e0;
    }

    #banner .list ul li:hover {
        background-color: #efdfe4;
    }
</style>
</head>
<body>
<style>
    #navTop {
        width: 100%;

        /*border-bottom: 1px solid #ccc;*/
    }

    .toTop {
        font-family: iconfont;
        position: fixed;
        right: 70px;
        bottom: 70px;
        line-height: 50px;
        text-align: center;
        border: 1px solid #CCCCCC;
        border-radius: 50px;
        color: #858585;
        width: 50px;
        font-size: 36px;
        cursor: pointer;
        background-color: #fff;
    }

    .toTop:hover, .toTop:focus {
        color: rgb(234, 42, 96);
    }

    body #headNav #header #showList dl {
        margin: 5px 16px;
    }

    body #headNav #header #showList #search button {
        height: 37px;
        overflow: hidden;
        padding: 7px 30px;
    }
</style>
<div id="navTop">
<div id="top">
<ul id="topleft" style="height:30px;line-height:25px;">
<li style=" margin-right:20px;float:left"><a href="javascript:void(0)" onclick="SetHome(this,window.location)" style="color: #757575;" title="加入收藏，方便下次打开">设为首页</a></li>
<li style=" margin-right:20px;float:left"><a href="javascript:void(0)" onclick="shoucang(document.title,window.location)" style="color: #757575;" title="加入收藏，方便下次打开">加入收藏</a></li>
<li style="float:left"><a href="<?php echo C('ftx_header_html');?>" target="_blank"><em class="icon-normal icon-phone"></em>手机版</a></li>
</ul>
<ul id="topright" style="line-height: 25px;">
<li><a target="_blank" style="color: #8da7cb" href="http://wpa.qq.com/msgrd?v=3&amp;uin=<?php echo C('ftx_qq');?>&amp;site=qq&amp;menu=yes">在线客服</a></li>
</ul>
<div class="clear"></div>
</div>
</div>
<div id="headNav">
<div id="header" style="padding-bottom: 10px;">
<a href="/" style="width: 400px; height: 55px;display: inline-block;float: left;    background-size: inherit;    background: url('<?php echo C('ftx_site_logo');?>')left top no-repeat;margin-top: 15px;">
</a>
<div id="showList">
<div id="search">
<form name="search" action="<?php echo C('ftx_site_url');?>" method="get">
<input type="hidden" name="m" value="search">
<input type="hidden" name="a" value="index">
<input type="text" x-webkit-speech name="k" autocomplete="off" onblur="this.value==''?this.value=this.title:null" onfocus="this.value==this.title?this.value='':null" title="搜优惠券..." value="搜优惠券..." />
<button type="submit">搜索</button>
</form> 
</div>
<dl>
<dt class="rg"></dt>
</dl>
<dl>
<dt class="zy"></dt>
</dl>
<dl>
<dt class="qc"></dt>
</dl>
</div>
<div class="clear"></div>
</div>
</div>
<div id="baner">
<div id="nav" style="font-size: 15px;">
<?php $tag_nav_class = new navTag;$data = $tag_nav_class->lists(array('type'=>'lists','style'=>'main','status'=>'1','cache'=>'0','return'=>'data',)); if(is_array($data)): $i = 0; $__LIST__ = $data;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$val): $mod = ($i % 2 );++$i;?><a class="<?php if($nav_curr == $val['alias']): if($val['alias'] == hot): ?>iconH<?php endif; if($val['alias'] == index): ?>iconM<?php endif; ?> active<?php endif; ?>" href="<?php echo ($val["link"]); ?>" <?php if($val['alias'] == index): ?>style="padding:8px 27px;"<?php else: ?>style="padding:8px 15px;"<?php endif; ?> <?php if($val["target"] == 1): ?>target="_blank"<?php endif; ?>><?php if($val['alias'] == index): ?><i class="iconfont">&#xe601;</i><span style="margin-right: 7px;"><?php echo ($val["name"]); ?></span><?php else: echo ($val["name"]); endif; if($val['alias'] == hot): ?><div style="position:absolute; width:24px; height:32px; background:#FFCC00;margin-left: 107px; margin-top: -25px; background:url(__STATIC__/san_www/images/HOTT_qeu.gif)"></div><?php endif; ?></a><?php endforeach; endif; else: echo "" ;endif; ?>
</div>
</div>
<div id="dtk_mian">
<div id="banner">
<div class="banner_con clearfix">
<div class="list fl">
<ul>
<li><i class="iconfont">&#xe603;</i><a href="<?php echo U('index/cate', array('cid'=>1));?>">服装 </a>
</li>
<li><i class="iconfont">&#xe607;</i><a href="<?php echo U('index/cate', array('cid'=>2));?>">母婴<em style=" margin-left: 10px; margin-top: 10px;width:9px; height:14px; position: absolute;background:url(__STATIC__/san_www/images/x_hot.gif);/* background-color: red; */"> </em></a></li>
<li><i class="iconfont">&#xe602;</i><a href="<?php echo U('index/cate', array('cid'=>3));?>">化妆品</a></li>
<li><i class="iconfont">&#xe609;</i><a href="<?php echo U('index/cate', array('cid'=>4));?>">居家、日用<em style=" margin-left: 4px; margin-top: 10px;width:9px; height:14px; position: absolute;background:url(__STATIC__/san_www/images/x_hot.gif);/* background-color: red; */"> </em></a>
</li>
<li><i class="iconfont">&#xe605;</i><a href="<?php echo U('index/cate', array('cid'=>5));?>">鞋包、配饰</a></li>
<li><i class="iconfont">&#xe604;</i><a href="<?php echo U('index/cate', array('cid'=>6));?>">美食</a></li>
<li><i class="iconfont">&#xe608;</i><a href="<?php echo U('index/cate', array('cid'=>7));?>">文体、车品</a>
</li>
<li><i class="iconfont">&#xe606;</i><a href="<?php echo U('index/cate', array('cid'=>8));?>">数码、家电</a></li>
</ul>
</div>
<?php echo R('advert/index', array(2), 'Widget');?>
<div class="rightPic fr" style="position: relative">
<div class="bdshare" style="position: absolute;top: 95px;left: 76px;">
<div class="bdsharebuttonbox"><a href="#" class="bds_more" data-cmd="more"></a><a href="#" class="bds_qzone" data-cmd="qzone" title="分享到QQ空间"></a><a href="#" class="bds_tsina" data-cmd="tsina" title="分享到新浪微博"></a><a href="#" class="bds_tqq" data-cmd="tqq" title="分享到腾讯微博"></a><a href="#" class="bds_weixin" data-cmd="weixin" title="分享到微信"></a><a href="#" class="bds_sqq" data-cmd="sqq" title="分享到QQ好友"></a></div>
<script>window._bd_share_config={"common":{"bdSnsKey":{},"bdText":"<?php echo ($page_seo["description"]); ?>","bdMini":"2","bdMiniList":false,"bdPic":"","bdStyle":"0","bdSize":"24"},"share":{}};with(document)0[(getElementsByTagName('head')[0]||body).appendChild(createElement('script')).src='http://bdimg.share.baidu.com/static/api/js/share.js?v=89860593.js?cdnversion='+~(-new Date()/36e5)];</script>
</div>
<a href="/hot" target="_blank" style="position:absolute;display:block;width:100%;height:143px;top:156px;"></a>
<img src="__STATIC__/san_www/images/hot.jpg" alt="" width="300" height="300">
</div>
</div>
</div>
<div id="content" style="padding-bottom: 58px;">
<div class="divider" style="text-align: left;padding: 0 10px;width: 1178px;border: 1px solid #ffd6d6; color: #9c9c9c;background-color: #FDFCE7;">
小编说：这些年，我们每天坚持为大家更新超值宝贝... 感谢您多年来的支持！无论再苦再苦，我们都会坚持下去！因为您的信任，我们会带着这份责任，做到极致... 
</div>
<div class="discount">
<div class="discount_head clearfix" style="margin-bottom: 10px;">
<div class="dishead_left fl" style="color: #fbacc2">
<h1 style="color: #585858;font-weight: normal;">领券秒杀精选</h1>
<span class="color_p pd">/</span>
<span class="color_p">实时更新</span>
<span class="color_p">/</span>
<span class="color_p">商家内部券</span>
</div>
<div class="dishead_right fr" style="color: #fbacc2">
<span class="color_p">/</span>
<span class="color_p">将优选、性价比做到极致</span>
<span class="color_p">/</span>
</div>
</div>
<div class="dis_product">
<?php $tag_item_class = new itemTag;$data = $tag_item_class->top_lists(array('type'=>'top_lists','num'=>'6','cache'=>'0','return'=>'data',)); if(is_array($data)): $i = 0; $__LIST__ = $data;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 2 );++$i;?><div class="pro_detail <?php if(($mod) == "1"): ?>fr<?php endif; ?>">
<a rel="nofollow" <?php echo ($item["itemurl"]); ?> target="_blank">
<img src="<?php echo attach(get_thumb($item['pic_url'], '_b'),'item');?>" height="272" style="border: 0;max-width:272px;"/>
</a>
<div class="pro_intro fr">
<p class="pro_title" style="max-height: 68px;overflow: hidden;;"><a <?php echo ($item["itemurl"]); ?> rel="nofollow" target="_blank" title="<?php echo ($item["title"]); ?>" style="color: #616161; font-size: 16px;"><?php echo ($item["title"]); ?></a>
</p>
<div class="pro_price color_p" style="color: #FB82A4;"><i class="iconfont" style="color:#fb973e;margin-right: 3px;">
&#xe60a;</i>内部券<em><?php echo ($item["q_price"]); ?></em>元，过期时间<span style="font-family: Arial; margin-left: 6px;"><?php echo ($item["q_time"]); ?></span>
</div>
<div class="residue">优惠券剩余<i class="color_p"><?php echo ($item["q_sur"]); ?></i>张，已领取 <span style="font-family: Arial; font-size: 14px;"><?php echo ($item["q_has"]); ?></span> 张
</div>
<div class="pro_nowPri"><span>下单价 ￥<em><?php echo ($item["coupon_price"]); ?></em></span>
在售价<em style="font-weight: normal;font-family: Arial;">￥<?php echo ($item["price"]); ?></em>
</div>
<div class="buy">
<span style="color: #999999;  ">购买流程：</span>
<a <?php echo ($item["quanurl"]); ?> target="_blank">
<span class="indexBorder"> ①点我领券</span>
</a>
<span class="indexto">> </span>
<a rel="nofollow" <?php echo ($item["ckurl"]); ?> target="_blank">
<span class="indexBorder">②点击下单</span>
</a>
</div>
</div>
</div><?php endforeach; endif; else: echo "" ;endif; ?>
</div>
</div>
<div class="quality">
<div class="discount_head clearfix" style="margin-bottom: 10px;">
<div class="dishead_left fl" style="color: #fbacc2">
<h1 style="color: #585858;font-weight: normal;">特卖精选</h1>
<span class="color_p pd">/</span>
<span class="color_p">人气款、评价好、性价比高</span>
<span class="color_p">/</span>
</div>
<div class="dishead_right fr">
<span class="color_p"><a style="color: #505050;font-size: 14px;" href="/temai">更多特卖</a></span>
<span class="color_p" style="color: #505050;"> »</span>
</div>
</div>
<ul class="clearfix index-boutique">
<?php $tag_item_class = new itemTag;$data = $tag_item_class->gy_lists(array('type'=>'gy_lists','num'=>'4','cache'=>'0','return'=>'data',)); if(is_array($data)): $i = 0; $__LIST__ = $data;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 4 );++$i;?><li style="background-color: #fff;" class="<?php if(($mod) == "3"): ?>no-right<?php endif; ?>">
<a <?php echo ($item["itemurl"]); ?> rel="nofollow" target="_blank">
<img src="<?php echo attach(get_thumb($item['pic_url'], '_b'),'item');?>" alt="">
</a>
<div class="padding">
<a target="_blank" rel="nofollow" <?php echo ($item["itemurl"]); ?> class="title  clearfix">
<?php if($item["shop_type"] == 'B' ): ?><i class="tmall"></i>
<?php else: ?>
<i class="taobao"></i><?php endif; ?>
<span><?php echo ($item["title"]); ?></span>
</a>
<div class="price-wrap clearfix">
<span class="icon">￥</span>
<span class="price"><?php echo ($item["coupon_price"]); ?></span>
<span class="youpin"></span>
<div class="sold-count">

<span class="num"><?php echo ($item["zk"]); ?> 折</span>
</div>
</div>
<div class="time-wrap clearfix">

<div class="date">
目前已售<?php echo ($item["volume"]); ?>
</div>
<a class="buy" <?php echo ($item["ckurl"]); ?> target="_blank" rel="nofollow">去抢购&gt;</a>
</div>
</div>
</li><?php endforeach; endif; else: echo "" ;endif; ?>
</ul>
</div>
<div class="live">
<div class="discount_head clearfix" style="margin-bottom: 10px;">
<div class="dishead_left fl">
<h1 style="font-weight: normal;">领券优惠直播<span class="tatal" style="background-color: #5dcac5;color: #FFFFFF;padding: 3px 7px;border-radius: 15px; font-family: 'Arial'; margin-left: 10px;"><?php echo ($total_item); ?></span>
</h1>
</div>
<div class="dishead_right fr">
<a href="/quan"><span style="color: #505050;font-size: 14px;" class="color_p">更多优惠 »</span></a>
</div>
</div>
<div class="goods-list main-container">
<ul class="clearfix index-boutique">
<?php if(is_array($items_list)): $i = 0; $__LIST__ = $items_list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 4 );++$i;?><li class="<?php if(($mod) == "3"): ?>no-right<?php endif; ?>">
<a <?php echo ($item["itemurl"]); ?> class="img" rel="nofollow" target="_blank">
<?php echo (sannewicon($item["coupon_start_time"])); ?>
<img src="<?php echo attach(get_thumb($item['pic_url'], '_b'),'item');?>" alt="">
</a>
<div class="padding">
<a target="_blank" <?php echo ($item["itemurl"]); ?> class="title clearfix">
<?php if($item["shop_type"] == 'B' ): ?><i class="tmall"></i>
<?php else: ?>
<i class="taobao"></i><?php endif; ?>
<span><?php echo ($item["title"]); ?></span>
</a>
<?php if($item["item_type"] == '2' ): ?><div class="coupon-wrap clearfix">
优惠券<span class="price"><?php echo ($item["q_price"]); ?></span>元，已有<span class="num"><?php echo ($item["volume"]); ?></span>人购买
</div>
<?php else: ?>
<div class="price-wrap clearfix" style="background:none;">
<span class="icon">￥</span>
<span class="price"><?php echo ($item["coupon_price"]); ?></span>
<span class="youpin"></span>
<div class="sold-count">
<span class="num"><?php echo ($item["zk"]); ?> 折</span>
</div>
</div>
<div class="time-wrap clearfix">
<div class="date">
目前已售<?php echo ($item["volume"]); ?>
</div>
<a class="buy" <?php echo ($item["ckurl"]); ?> target="_blank" rel="nofollow">去抢购&gt;</a>
</div><?php endif; ?>
</div>
<?php if($item["item_type"] == '2' ): ?><div class="price-wrap clearfix">
<span class="price">
<span class="text">券后价&nbsp;￥<span class="price"><?php echo ($item["coupon_price"]); ?></span></span>
<span class="text" style="margin-left: 15px; font-size: 12px;color: #ffe4ed;">正常售价&nbsp;￥<?php echo ($item["price"]); ?> </span>
</span>
</div><?php endif; ?>
</li><?php endforeach; endif; else: echo "" ;endif; ?>
</ul>
</div>
</div>
<div class="mainbody_6" style="margin: 0 auto;margin-bottom: 0px;margin-top: 26px;">
<div id="yw0" class="pager">
<?php echo ($page); ?>
</div> 
</div>
</div>
<script>
    $(document).ready(function (e) {
        var unslider04 = $('#b04').unslider({
                dots: true
            }),
            data04 = unslider04.data('unslider');

        $('.unslider-arrow04').click(function () {
            var fn = this.className.split(' ')[1];
            data04[fn]();
        });
    });
</script>
</div>
<div id="footer" style="background-color: #373737;height: 190px;width: 100%;border-top: 3px solid #ff3366;">
<div class="footer-wrapper " style="width: 1200px;margin: 0 auto;position: relative;text-align: center">
<img src="__STATIC__/san_www/images/bottom_text.png" alt="" style="border: 0;margin-top: 50px;">

<div class="text" style="color: #a2a2a2;
    font-size: 16px;
    margin-top: 33px;">Copyright &copy; 2010 - 2016  <a href="<?php echo C('ftx_site_url');?>"><?php echo C('ftx_site_name');?></a> All Rights Reserved  <?php echo C('ftx_statistics_code');?> &nbsp;<a href="http://www.miibeian.gov.cn" target="_blank"><?php echo C('ftx_site_icp');?></a> &nbsp;&nbsp; 
</div>
</div>
</div>
<div class="toTop" style="display: none" onclick=" $('body,html').animate({scrollTop:0},1000);">
&#xe60c;</div>
<script type="text/javascript">
    // 设置为主页
    function SetHome(obj, vrl) {
        try {
            obj.style.behavior = 'url(#default#homepage)';
            obj.setHomePage(vrl);
        }
        catch (e) {
            if (window.netscape) {
                try {
                    netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");
                }
                catch (e) {
                    alert("此操作被浏览器拒绝！\n请在浏览器地址栏输入“about:config”并回车\n然后将 [signed.applets.codebase_principal_support]的值设置为'true',双击即可。");
                }
                var prefs = Components.classes['@mozilla.org/preferences-service;1'].getService(Components.interfaces.nsIPrefBranch);
                prefs.setCharPref('browser.startup.homepage', vrl);
            } else {
                alert("您的浏览器不支持，请按照下面步骤操作：1.打开浏览器设置。2.点击设置网页。3.输入：" + vrl + "点击确定。");
            }
        }
    }
    // 加入收藏 兼容360和IE6
    function shoucang(sTitle, sURL) {
        try {
            window.external.addFavorite(sURL, sTitle);
        }
        catch (e) {
            try {
                window.sidebar.addPanel(sTitle, sURL, "");
            }
            catch (e) {
                alert("加入收藏失败，请使用Ctrl+D进行添加");
            }
        }
    }

    $(function () {

        $(window).scroll(function () {
            if ($(window).scrollTop() > 500) {
                $(".toTop").fadeIn(1000);
            }
            else {
                $(".toTop").fadeOut(1000);
            }
        });
    });
</script>
<script type="text/javascript">
var yangtataER = {
    root: "__ROOT__",
	site: "<?php echo C('ftx_site_url');?>"
};
var lang = {};
<?php $_result=L('js_lang');if(is_array($_result)): $i = 0; $__LIST__ = $_result;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$val): $mod = ($i % 2 );++$i;?>lang.<?php echo ($key); ?> = "<?php echo ($val); ?>";<?php endforeach; endif; else: echo "" ;endif; ?>
</script>
<script type="text/javascript" src="__STATIC__/san_www/js/scrollTop2.js"></script>
<?php echo C('ftx_taojindian_html');?>
</body>
</html>