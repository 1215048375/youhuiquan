<?php if (!defined('THINK_PATH')) exit();?><div class="unslider fl">
<div class="banner" id="b04">
<ul style="width: 720px;height: 300px;overflow: hidden;">
<?php if(is_array($ad_list)): $i = 0; $__LIST__ = $ad_list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$ad): $mod = ($i % 2 );++$i;?><li>
<a href="<?php echo ($ad["url"]); ?>" target="_blank">
<img style="border: 0" src="<?php echo attach($ad['content'],'banner');?>" width="720" height="300" alt="<?php echo ($ad["name"]); ?>" title="<?php echo ($ad["desc"]); ?>">
</a>
</li><?php endforeach; endif; else: echo "" ;endif; ?>
</ul>
<a href="javascript:void(0);" class="unslider-arrow04 prev"><img class="arrow" id="al" src="__STATIC__/san_www/images/arrowl.png" alt="prev" width="25" height="50"></a>
<a href="javascript:void(0);" class="unslider-arrow04 next"><img class="arrow" id="ar" src="__STATIC__/san_www/images/arrowr.png" alt="next" width="25" height="50"></a>
</div>
</div>