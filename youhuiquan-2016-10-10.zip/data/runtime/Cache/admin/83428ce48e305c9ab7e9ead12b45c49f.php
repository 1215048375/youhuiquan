<?php if (!defined('THINK_PATH')) exit();?><div class="dialog_content pad_10">
	<div class="loading">
		采集信息：共 [ <b class="blue"><?php echo ($totalnum); ?></b> ] 个商品，正在采集第 [ <b class="blue"><?php echo ($p); ?></b> ] 个，采集成功 [ <span class="blue"><?php echo ($totalcoll); ?></span> ] 个商品。
	</div>
	<div align="center" class="red">
		采集时自动过滤<?php echo ($lowyj); ?>元以下佣金及已领光的优惠券。
	</div>
</div>
<script>
$(function(){
var p= <?php echo ($p); ?>;
 $('#page').val(p);  
});
</script>