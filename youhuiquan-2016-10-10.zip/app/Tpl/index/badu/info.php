<?php
return array(
    'name' => '优惠券',
    'author' => '爱挑挑',
    'author_url' => 'http://aitiaotiao.com',
    'version' => '淡雅红V2',
);
?>
