<?php
return array(
    'name' => '凑呗',
    'author' => '爱挑挑',
    'author_url' => 'http://www.coubei.com/?t',
    'version' => 'V0.1',
);
?>
