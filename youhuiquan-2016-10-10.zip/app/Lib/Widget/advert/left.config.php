<?php
return array(
  'name' => '大屏轮播左则',
  'option' => true,
  'allow_type' => array('image'),
);