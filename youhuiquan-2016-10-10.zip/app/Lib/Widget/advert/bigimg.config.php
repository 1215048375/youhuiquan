<?php
return array(
  'name' => '首页中间大屏轮播',
  'option' => true,
  'allow_type' => array('image'),
);