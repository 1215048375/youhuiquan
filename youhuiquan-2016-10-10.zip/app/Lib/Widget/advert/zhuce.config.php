<?php
return array(
  'name' => '注册页图片广告位',
  'option' => true,
  'allow_type' => array('image'),
);