<?php
return array(
  'name' => '搭配频道右广告位',
  'option' => true,
  'allow_type' => array('image'),
);