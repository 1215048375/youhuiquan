<?php
return array(
  'name' => '大淘客模板wap首页广告位',
  'option' => true,
  'allow_type' => array('image'),
);